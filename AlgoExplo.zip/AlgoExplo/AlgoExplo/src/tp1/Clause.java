package tp1;

import java.util.ArrayList;
import java.util.Dictionary;

public class Clause {

	protected Dictionary<Variable,Boolean> c;

	public Clause(){
		c = new Dictionary<Variable,Boolean>();
	}

	public Dictionary<Variable,Boolean> getVariables(){
		return c;
	}

	public Variable getVariableAtIndex(int i){
		return c.get(i);
	}

	public void addVariable(Variable v){
		if (!c.contains(v)) 
			c.add(v);
	}
}
