package tp1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Formule {

	protected ArrayList<Clause> f;

	public Formule(){
		f = new ArrayList<Clause>();
	}

	public ArrayList<Clause> getFormule(){
		return f;
	}

	public Clause getClauseAtIndex(int i){
		return f.get(i);
	}

	public void addClause(Clause  c){
		if (!f.contains(c))
			f.add(c);
	}
	
	public void Parser(String path) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader(path));
		String line;
		
		while ((line = br.readLine()).startsWith("c"))
		{
			line = br.readLine();
		}
	
	line = br.readLine(); // elimine la ligne (p cnf 20 91)
	while((line = br.readLine())
	}
}
