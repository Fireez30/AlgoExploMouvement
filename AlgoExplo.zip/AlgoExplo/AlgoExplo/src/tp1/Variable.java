package tp1;

import java.util.List;

public class Variable {

	protected String name;
	protected boolean value;
	protected List<Integer> clauses;
	
	public Variable(String s){
		name = s;
	}

	public boolean getValue(){
		return value;
	}

	public String getName(){
		return name;
	}
	
	public void addAtClause(int i){
		if (!clauses.contains(i))
			clauses.add(i);
	}
	
	public List<Integer> getListeClauses(){
		return clauses;
	}
 
}
