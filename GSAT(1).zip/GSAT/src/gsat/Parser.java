/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gsat;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/**
 *
 * @author rchamoulaud
 */
public class Parser {
    ArrayList<Clause> clauses;
    HashMap<String, Boolean> allDef;
    HashMap<String, Integer> incorrect;
    String lastAt="";
    Parser (String path){
        try{
            allDef = new HashMap();
            clauses = new ArrayList();
            System.out.println("Chargement du fichier : "+ new java.io.File( "." ).getCanonicalPath()+ "/cnf/" + path);
            path = new java.io.File( "." ).getCanonicalPath()+ "/cnf/" + path;
            BufferedReader readFile = new BufferedReader(new FileReader (path));
            System.out.println("Lecture du fichier "+ path);
            String s = readFile.readLine();
            while(s.charAt(0)!='p'){
                s=readFile.readLine();
            }
            s=readFile.readLine();
            int i=0;
            while (s!= null && s.length()!= 0 && s.charAt(0)!='%') {
                while(s.charAt(0)==' ')
                    s=s.substring(1);
                ArrayList<Atom> atoms = new ArrayList();
                String[] fact = s.split(" ");
                for(int j=0;j<fact.length-1;j++){
                    Atom a = new Atom(fact[j]);
                    if(allDef.containsKey(a.getName()))
                        a.setValue(allDef.get(a.getName()));
                    else{
                        Random r = new Random();
                        boolean val = r.nextInt(2) == 0;
                        a.setValue(val);
                        allDef.put(a.getName(), val);
                    }
                    atoms.add(a);
                }
                clauses.add(new Clause(atoms));
                s = readFile.readLine();
                i++;
            }
            readFile.close();
        }
        catch (IOException e){
            System.out.println("Erreur lecture fichier : \n"+ e);
        }
    }
    public void resolve(){
        int i=0, maxTries= 10000;
        Random r = new Random();
        while(!isCorrect() && i<maxTries){
            String[] keys = incorrect.keySet().toArray(new String[0]);
            int max=-1,iMax=-1, iC=0;
            /*for(Integer j : incorrect.values()){
                if(j > max && !lastAt.equals(keys[j])){
                    iMax=iC;
                    lastAt=keys[j];
                    max = j;
                }
                iC++;
            }
            System.out.println(keys[iMax]);*/
            iMax = r.nextInt(incorrect.size());
            allDef.put(keys[iMax], !allDef.get(keys[iMax]));
            for(Clause c : clauses)
                c.changeValAtom(keys[iMax], allDef.get(keys[iMax]));
            i++;
        }
        if(isCorrect()){
            System.out.println("Solution trouvée");
            System.out.println("Nombre essais : "+i);
            System.out.println("Solution : \n"+allDef);
        }
        else
            System.out.println("Pas de solution trouvée");
    }
    public boolean isCorrect(){
        boolean correct = true;
        incorrect = new HashMap();
        for(Clause c : clauses){
            correct = correct && c.isCorrect();
            if(!c.isCorrect()){
                ArrayList<Atom> incHere = c.getIncorrect();
                for(Atom a : incHere){
                    if(!incorrect.containsKey(a.getName()))
                        incorrect.put(a.getName(),1);
                    else
                        incorrect.put(a.getName(),incorrect.get(a.getName())+1);
                }
            }
        }
        System.out.println("Liste atom qui amène à une erreur :");
        System.out.println(incorrect);
        return correct;
    }
    public String toString(){
        String r="";
        for(int i =0;i<clauses.size();i++){
            r+=clauses.get(i).toString()+"\n";
        }
        return r;
    }
}
