/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSAT;

/**
 *
 * @author rchamoulaud
 */
public class Atom {
    boolean value,sign;
    String name;
    
    Atom(String s){
        if(s.charAt(0)=='-'){
            sign=false;
            name = s.substring(1);
        }
        else{
            sign=true;
            name = s;
        }
    }
    Atom(String s, boolean b){
        if(s.charAt(0)=='-'){
            value = !b;
            sign=false;
            name = s.substring(1);
        }
        else{
            sign=true;
            value = b;
            name = s;
        }
    }
    public String getName(){
        return name;
    }
    public void setValue(boolean b){
        if(sign)
            value = b;
        else
            value = !b;
    }
    public boolean isCorrect(){
        return value;
    }
    
    public boolean equals(Object o){
        if(o instanceof Atom){
            Atom a = (Atom)o;
            return a.getName().equals(name);
        }
        return false;
    }
    public String toStringSign(){
        if(sign)
            return " "+name; 
        else
            return " -"+name; 
    }
    public String toString(){
        return " "+name; 
    }
}
