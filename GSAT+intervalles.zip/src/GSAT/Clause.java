package GSAT;

import java.util.ArrayList;
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Romain
 */
public class Clause {
    ArrayList<Atom> atoms;
    ArrayList<Atom> correct,incorrect;
    Clause(ArrayList<Atom> at){
        atoms=at;
    }
    
    public ArrayList<Atom> getCorrect(){
        return correct;
    }
    public ArrayList<Atom> getIncorrect(){
        return incorrect;
    }
    public boolean isCorrect(){
        triAtom();
        return !correct.isEmpty();
    }
    public void triAtom(){        
        correct = new ArrayList();
        incorrect = new ArrayList();
        for(Atom a : atoms){
            if(a.isCorrect())
                correct.add(a);
            else
                incorrect.add(a);
        }
    }
    public void changeValAtom(String s, boolean b){
        for(Atom a : atoms){
            if(a.getName().equals(s))
                a.setValue(b);
        }
    }
    @Override
    public String toString(){
        String r="";
        for(Atom a : atoms){
            r+=a+" U";
        }
        return r;
    }
}
