
package util;

public abstract class Constraint {

    public Constraint() {}

    public abstract boolean violated(Box box);
}
