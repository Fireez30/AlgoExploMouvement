
package util;

public abstract class Function {

    public abstract Interval eval(Box x);
}
