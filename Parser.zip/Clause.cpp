#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include "Variable.cpp"


using namespace std;

class Clause {

	string nom;
	vector<Variable> variables;

	public : 

	Clause(){
		nom = "";
		variables = vector<Variable>();
	}

	Clause(string n){
		nom = n;
		variables = vector<Variable>();
	}

	~Clause(){
		variables.clear();
	}

	bool execClause(){
		bool flag = false;
		for (int i=0; i < variables.size(); i++){
			if (variables[i].getValeur())
				flag = true;
		}

		return flag;
	}
	
	vector<Variable> getVariables(){
		return variables;
	}

	void addVariable(Variable v){
			variables.push_back(v);
	}

	string getNom(){
		return nom;
	}

	void setNom(string s){
		nom = s;
	}

};