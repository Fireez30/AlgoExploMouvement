#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <fstream>
#include "Clause.cpp"

using namespace std;

bool contains(vector<string> liste,string tmp){
	    bool flag = false;
   		for (int i = 0;i < liste.size(); i++){
 			if (liste[i] == tmp)
  					flag = true;
  		}

  		return flag;
}

vector<Clause> parser(string path){
	vector<Clause> result = vector<Clause>();
	vector<string> vars = vector<string>();

	ifstream fichier(path);
	if(!fichier) 
        {       
            cerr << "Impossible d'ouvrir le fichier !" << endl;
        }

        string ligne;
        getline(fichier,ligne);
        while (ligne[0] == 'c')
        {
        	cout << ligne << endl;
        	getline(fichier,ligne);
        }
        getline(fichier,ligne);
        while (ligne.front() != '%' && ligne.front() != '0')
        {
        	string tmp2;
        	fichier >> tmp2;
        	if (tmp2 == "%")
        		break;
        	cout << "new clause !" << endl;
        	Clause c = Clause(ligne);

        	while (tmp2 != "0" && tmp2 != ""){
        		cout << " Variable :" << tmp2 << "." << endl;
        		Variable v = Variable(tmp2,false);
        		vars.push_back(tmp2);
        		c.addVariable(v);

        		fichier >> tmp2;
        	}

        	result.push_back(c);
        	getline(fichier,ligne);
    	}

    	fichier.close();
    	return result;
}

bool execFormule(vector<Clause> f){
		bool flag = true;
		for (int i=0; i < f.size(); i++){
			if (!f[i].execClause())
				flag = false;
		}

		return flag;
}

int main(int argc,char **argv){
	vector<Clause> f = parser("uf20-04.cnf");
    cout << f[0].getVariables()[0].getNom() << endl;
    cout << f[0].getVariables()[1].getNom() << endl;
    cout << f[0].getVariables()[2].getNom() << endl;
	return 0;	
}