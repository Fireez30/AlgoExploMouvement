#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

using namespace std;
class Variable {

	string nom;
	bool valeur;
	vector<string> clause;

	public : 

	Variable(){
		nom = "";
		valeur = false;
		clause = vector<string>();
	}

	Variable(string n,bool v){
		nom = n;
		valeur = v;
		clause = vector<string>();
	}

	~Variable(){
		clause.clear();
	}

	vector<string> getRelatedClauses(){
		return clause;
	}

	void addRelatedClause(string v){
			clause.push_back(v);
	}

	bool getValeur(){
		return valeur;
	}

	void setValeur(bool b){
		valeur = b;
	}

	string getNom(){
		return nom;
	}

	void setNom(string s){
		nom = s;
	}

};